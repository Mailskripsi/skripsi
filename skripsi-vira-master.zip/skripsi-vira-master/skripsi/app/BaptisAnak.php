<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BaptisAnak extends Model
{
    protected $table = 'sakramen_baptis_anak';

}
