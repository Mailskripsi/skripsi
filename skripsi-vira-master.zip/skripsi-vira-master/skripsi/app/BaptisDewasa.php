<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BaptisDewasa extends Model
{
    protected $table = 'sakramen_baptis_dewasa';
}
