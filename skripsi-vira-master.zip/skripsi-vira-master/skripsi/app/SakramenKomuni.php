<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SakramenKomuni extends Model
{
    protected $table = 'sakramen_komuni_pertama';
}
