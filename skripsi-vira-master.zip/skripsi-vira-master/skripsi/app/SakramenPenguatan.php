<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SakramenPenguatan extends Model
{
    protected $table = 'sakramen_penguatan';
}
