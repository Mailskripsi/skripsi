<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SakramenPerkawinan extends Model
{
    protected $table = 'sakramen_perkawinan';
}
