@extends('layouts.admin')

@section('content')

    <center>
        <h1>Selamat Datang Admin</h1>
    </center>

@endsection
