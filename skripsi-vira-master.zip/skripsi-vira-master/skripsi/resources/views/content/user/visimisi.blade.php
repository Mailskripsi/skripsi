@extends('layouts.user')

@section('content')
    <div class="container p-2 my-2">
        <div class="row">
            <div class="col-12">
                <div class="container p-1 border">
                    <h2>Visi-Misi</h2>
                        <p>Visi-Misi Gereja Pangkalan Santo Mikael Adisutjipto Yogyakarta<br>
                            <br>
                                Berdasarkan website resmi Tentara Nasional Indonesia (https://tni.mil.id/pages-1-visi-dan-misi-tni.html), berikut dipaparkan Visi TNI yang berbunyi demikian : Visi TNI adalah terwujudnya Pertahanan Negara yang Tangguh. Misi TNI adalah menjaga Kedaulatan dan Keutuhan Wilayah Negara Kesatuan Republik Indonesia (NKRI) serta Keselamatan Bangsa.
                        </p>
                </div>
            </div>
          </div>
    </div>
@endsection