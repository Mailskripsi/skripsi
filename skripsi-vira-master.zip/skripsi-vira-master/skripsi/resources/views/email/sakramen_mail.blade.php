<h3>Selamat,</h3>
<h4>anda sudah terdaftar sebagai calon penerimaan sakramen {{ $nama_sakramen }}</h4>
<br>
<h5>Silahkan melakukan pembayaran ke : 1234567 (BRI, An.maria alvira)</h5>
<p>Batas Konfirmasi Pembayaran sampai tanggal
<h4>{{ $batas_konfirmasi }}</h4>, konfirmasi bisa langsung ke
link berikut :
https://wa.me/6282335777636</p>

<p>Selamat datang di <a href="//www.malasngoding.com/kirim-email-dengan-laravel/">www.malasngoding.com</a></p>
<p>Tutorial Laravel #35 : kirim email dengan laravel.</p>
